<template>
    <div class="seller">
        我是seller
    </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'seller'
  };
</script>

<style lang="stylus" rel="stylesheet/stylus">
</style>