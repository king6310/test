<template>
    <div class="ratings">
        我是ratings
    </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'ratings'
  };
</script>

<style lang="stylus" rel="stylesheet/stylus">
</style>